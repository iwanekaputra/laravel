@extends('landingpage.index')   
@section('content')    

    @include('landingpage.partials.about')
    @include('landingpage.partials.service')
    @include('landingpage.partials.team')
    @include('landingpage.partials.pricing')
    @include('landingpage.partials.frequently')

@endsection