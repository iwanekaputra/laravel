  <!-- ======= Hero Section ======= -->
  <section id="hero">

    <div class="container">
      <div class="row d-flex align-items-center">
      <div class=" col-lg-6 py-5 py-lg-0 order-2 order-lg-1" data-aos="fade-right">
        <h1>SIMPEKU</h1>
        <h2>Sistem Peminjaman Buku Berbasis Web.</h2>
        <a href="#about" class="btn-get-started scrollto">Detail</a>
      </div>
      <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
        <img src="<?php echo e(asset('img/hero/hero-1.png')); ?>" class="img-fluid" alt="">
      </div>
    </div>
    </div>

  </section><!-- End Hero -->
<?php /**PATH G:\laravel\laravel8-app\resources\views/landingpage/hero.blade.php ENDPATH**/ ?>