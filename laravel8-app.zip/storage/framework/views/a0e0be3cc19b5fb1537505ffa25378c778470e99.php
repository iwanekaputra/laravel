<div class="footer-top">

<div class="container">

  <div class="row  justify-content-center">
    <div class="col-lg-6">
      <h3>SIMPEKU</h3>
      <p>Et aut eum quis fuga eos sunt ipsa nihil. Labore corporis magni eligendi fuga maxime saepe commodi placeat.</p>
    </div>
  </div>

  <div class="row footer-newsletter justify-content-center">
    <div class="col-lg-6">
      <form action="" method="post">
        <input type="email" name="email" placeholder="Enter your Email"><input type="submit" value="Subscribe">
      </form>
    </div>
  </div>

  <div class="social-links">
    <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
    <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
    <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
    <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
    <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
  </div>

</div>
</div>

<div class="container footer-bottom clearfix">
<div class="copyright">
  &copy;Kampus Merdeka<strong><span>SIMPEKU</span></strong>
</div>
<div class="credits">
  <!-- All the links in the footer should remain intact. -->
  <!-- You can delete the links only if you purchased the pro version. -->
  <!-- Licensing information: https://bootstrapmade.com/license/ -->
  <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bocor-bootstrap-template-nice-animation/ -->
  Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
</div>
</div>
<?php /**PATH G:\laravel\laravel8-app\resources\views/landingpage/footer.blade.php ENDPATH**/ ?>