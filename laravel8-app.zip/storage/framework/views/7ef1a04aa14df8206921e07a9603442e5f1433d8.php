<?php $__env->startSection('section'); ?>
<div class="main-container">
	<div class="xs-pd-20-10 pd-ltr-20">
		<div class="page-header">
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<div class="title">
						<h4>Buku</h4>
					</div>
					<nav aria-label="breadcrumb" role="navigation">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Semua Buku</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
		<!-- Export Datatable start -->
		<div class="card-box mb-30">
			<div class="pd-20">
				<h4 class="text-blue h4">Semua Buku</h4>
			</div>
			<div class="pb-20">
				<table class="table hover multiple-select-row data-table-export nowrap">
					<thead>
						<tr>
							<th>NO</th>
							<th>JUDUL</th>
							<th>ISBN</th>
							<th>STOCK</th>
							<th>OPSI</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($loop->iteration); ?></td>
								<td><?php echo e($buku->judul); ?></td>
								<td><?php echo e($buku->isbn); ?></td>
								<td><?php echo e($buku->stok); ?></td>
								<td>
									<form action="<?php echo e(route('buku.destroy', $buku->id)); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<a class="badge badge-primary" href="<?php echo e(route('buku.edit',$buku->id)); ?>">Edit</a>

										<a href="#" class="badge badge-info" data-toggle="modal" data-target="#small-modal-<?php echo e($buku->id); ?>" type="button">Detail
										</a>										
										<?php echo method_field('DELETE'); ?>
										<button type="submit" class="badge badge-danger border-0" onclick="return confirm('data yakin dihapus?')">Delete</i></button>
										
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
		<!-- Export Datatable End -->
	</div>
</div>

<br>

<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="small-modal-<?php echo e($detail->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel">Detail</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			</div>
			<div class="modal-body">
				<div class="row">
				<div class="col-md-5">
					<img src="<?php echo e(asset('admin/vendors/images/' . $detail->cover)); ?>" alt="" class="bg_img">
				</div>
				<div class="col-md-7">
					<table class="table">                    
	               	<tbody>
	                   <tr>
	                       <th>Judul</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->judul); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Isbn</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->isbn); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Halaman</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->halaman); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Penerbit</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->penerbit->nama); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Pengarang</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->pengarang->nama); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Kategori</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->kategori->nama); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Rak</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->rak->nama); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Stok</th>
	                       <td>:</td>
	                       <td><?php echo e($detail->stok); ?></td>
	                   </tr>
	                   <tr>
	                       <th>Deskripsi</th>
	                       <td>:</td>
	                       <td></td>
	                   </tr>
	               	</tbody>
           			</table>
	                   <p align="justify"><?php echo $detail->deskripsi; ?></p>
        		</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
							
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\laravel8-app\resources\views/admin/buku/index.blade.php ENDPATH**/ ?>