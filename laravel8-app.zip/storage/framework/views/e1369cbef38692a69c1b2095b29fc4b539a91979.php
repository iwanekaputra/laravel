

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row mt-5">
    <div class="col-lg-3">
        <ul class="list-unstyled templatemo-accordion">
            <li class="pb-3">
                <a class="collapsed d-flex justify-content-between h3 text-decoration-none" href="#">
                    Kategori
                </a>
                <ul class="collapse show list-unstyled pl-3">
                	<?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a class="text-decoration-none" href="/buku?kategori=<?php echo e($kategori->nama); ?>"><?php echo e($kategori->nama); ?></a></li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        </ul>
    </div>
    <div class="col-lg-9">
      <div class="row">
			<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-6">
				<div class="blog-list">
					<ul>
						<li>
						<div class="row no-gutters">
							<div class="col-lg-4 col-md-12 col-sm-12">
								<div class="blog-img">
									<img src="<?php echo e(asset('admin/vendors/images/' . $buku->cover)); ?>" alt="" class="bg_img">
								</div>
							</div>
							<div class="col-lg-8 col-md-12 col-sm-12">
								<div class="blog-caption">
									<h4><a href="#"><?php echo e($buku->judul); ?></a></h4>
									<div class="blog-by">
										<p>Isbn : <?php echo e($buku->isbn); ?></p>
										<p>Penerbit : <?php echo e($buku->penerbit->nama); ?></p>
										<p>Pengarang : <?php echo e($buku->pengarang->nama); ?></p>
										<p>Kategori : <?php echo e($buku->kategori->nama); ?></p>
										<div class="pt-10">
										<a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#bd-example-modal-lg-<?php echo e($buku->id); ?>" type="button">Detail</a>
										<?php if(auth()->guard()->check()): ?>
											<a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#bd-example-modal-lg-<?php echo e($buku->id); ?>-pinjam" type="button">Pinjam</a>
										<?php else: ?> 
											<a href="#" class="btn btn-outline-primary" data-backdrop="static" data-toggle="modal" data-target="#login-modal" type="button">Pinjam</a>

										<?php endif; ?>
										
										</div>
									</div>
								</div>
							</div>
						</div>
						</li>
					</ul>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
  </div>
</div>




<!-- Large modal -->
	<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="modal fade bs-example-modal-lg" id="bd-example-modal-lg-<?php echo e($detail->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="myLargeModalLabel"><?php echo e($detail->judul); ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">
						<div class="row">
						<div class="col-md-5">
							<img src="<?php echo e(asset('admin/vendors/images/' . $detail->cover)); ?>" alt="" class="bg_img">
						</div>
						<div class="col-md-7">
							<table class="table">                    
               <tbody>
                   <tr>
                       <th>Judul</th>
                       <td>:</td>
                       <td><?php echo e($detail->judul); ?></td>
                   </tr>
                   <tr>
                       <th>Isbn</th>
                       <td>:</td>
                       <td><?php echo e($detail->isbn); ?></td>
                   </tr>
                   <tr>
                       <th>Halaman</th>
                       <td>:</td>
                       <td><?php echo e($detail->halaman); ?></td>
                   </tr>
                   <tr>
                       <th>Penerbit</th>
                       <td>:</td>
                       <td><?php echo e($detail->penerbit->nama); ?></td>
                   </tr>
                   <tr>
                       <th>Pengarang</th>
                       <td>:</td>
                       <td><?php echo e($detail->pengarang->nama); ?></td>
                   </tr>
                   <tr>
                       <th>Kategori</th>
                       <td>:</td>
                       <td><?php echo e($detail->kategori->nama); ?></td>
                   </tr>
                   <tr>
                       <th>Rak</th>
                       <td>:</td>
                       <td><?php echo e($detail->rak->nama); ?></td>
                   </tr>
                   <tr>
                       <th>Stok</th>
                       <td>:</td>
                       <td><?php echo e($detail->stok); ?></td>
                   </tr>
                   <tr>
	                     <th>Deskripsi</th>
	                     <td>:</td>
	                     <td></td>
	                  </tr>
               </tbody>
           		</table>
           			<p align="justify"><?php echo $detail->deskripsi; ?></p>
        		</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="modal fade bs-example-modal-lg" id="bd-example-modal-lg-<?php echo e($pinjam->id); ?>-pinjam" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h4 align="" class="modal-title text-center" id="myLargeModalLabel">Silahkan Isi data terlebih dahulu</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">
						<form action="<?php echo e(url('/buku')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<input type="hidden" value="<?php echo e($pinjam->id); ?>" name="buku_id">
							<div class="form-group">
								<label>Nama Asli</label>
								<input class="form-control" type="text" placeholder="Nama" name="nama">
							</div>
							<div class="form-group">
								<label>Jumlah</label>
								<input class="form-control" type="text" placeholder="Jumlah" name="jumlah">
							</div>
							<div class="form-group">
									<label>Tanggal Pinjam</label>
									<input class="form-control" placeholder="Select Date" type="date" name="tgl_pinjam">
								</div>
							<div class="form-group">
									<label>Tanggal Pengembalian</label>
									<input class="form-control" placeholder="Select Date" type="date" name="tgl_kembali">
								</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-primary">Pinjam</button>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<!-- Login modal -->
	
<?php $__env->stopSection(); ?>




<?php echo $__env->make('landingpage.buku.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\laravel8-app\resources\views/landingpage/buku/index.blade.php ENDPATH**/ ?>