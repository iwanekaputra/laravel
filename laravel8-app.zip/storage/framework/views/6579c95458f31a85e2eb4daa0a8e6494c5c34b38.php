

<?php $__env->startSection('content'); ?>
	
<div class="container">
	<h2 class="text-center mt-5">Buku yang dipinjam</h2>
	<div class="row mt-5 mb-5">
		<div class="col-md">	
			<table class="table table-bordered text-center">
			  <thead>
			    <tr>
			      <th scope="col">No</th>
			      <th scope="col">Nama Buku</th>
			      <th scope="col">Jumlah Dipinjam</th>
			      <th scope="col">Waktu Pinjam</th>
			      <th scope="col">Waktu Pengembalian</th>
			      <th scope="col">Keterangan</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<tr>
				      <th scope="row"><?php echo e($loop->iteration); ?></th>
				      <th scope="row"><?php echo e($peminjam->buku->judul); ?></th>
				      <th scope="row"><?php echo e($peminjam->jumlah); ?></th>
				      <th scope="row"><?php echo e($peminjam->created_at); ?></th>
				      <th scope="row"><?php echo e($peminjam->tgl_kembali); ?></th>
				      <?php if($peminjam->keterangan_id == 1 || $peminjam->keterangan_id == 3): ?>
				      <form action="<?php echo e(url('batal', $peminjam->id)); ?>" method="POST">
				      	<?php echo csrf_field(); ?>
				      	<th scope="row">
				      		<input type="hidden" value="<?php echo e($peminjam->id); ?>" name="id">
				      		<button class="badge badge-secondary border-0" type="submit">Batal</button>
				      		<button class="badge badge-danger border-0"><?php echo e($peminjam->keterangan->status); ?></button></th>
				      	</form>
				      <?php elseif($peminjam->keterangan_id == 2): ?>
				      	<th scope="row"><button class="badge badge-success border-0"><?php echo e($peminjam->keterangan->status); ?></th></button>
				      <?php endif; ?>
				    </tr>
			  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
			  </tbody>
			</table>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('landingpage.buku.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\laravel8-app\resources\views/siswa/index.blade.php ENDPATH**/ ?>