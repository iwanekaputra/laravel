<?php $__env->startSection('section'); ?>
<div class="main-container">
		<div class="xs-pd-20-10 pd-ltr-20">
			<div class="page-header">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<div class="title">
							<h4>Dashboard</h4>
						</div>
						<nav aria-label="breadcrumb" role="navigation">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
							</ol>
						</nav>
					</div>
					<div class="col-md-6 col-sm-12 text-right">
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
							Tambah Buku
						</button>
					</div>
				</div>
			</div>


				<!-- Export Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">Detail</h4>
					</div>
					<div class="pb-20">
						<table class="table hover multiple-select-row data-table-export nowrap">
							<thead>
								<tr>
									<th>NO</th>
									<th>JUDUL</th>
									<th>ISBN</th>
									<th>STOCK</th>
									<th>OPSI</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($buku->judul); ?></td>
										<td><?php echo e($buku->isbn); ?></td>
										<td><?php echo e($buku->stok); ?></td>
										<td>
											<a class="badge badge-primary" href="<?php echo e(route('buku.edit',$buku->id)); ?>">Edit</a>
											<a class="badge badge-info" href="<?php echo e(route('buku.show',$buku->id)); ?>">Detail</a>
											<form action="<?php echo e(route('buku.destroy', $buku->id)); ?>" method="POST">
											</a>
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<button type="submit" class="badge badge-danger border-0" onclick="return confirm('data yakin dihapus?')">Delete</i></button>
												
											</form>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
</div>

    </div>

<br>
			
		

	<?php echo $__env->make('admin.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	


<?php $__env->stopSection(); ?>
							
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\laravel8-app\resources\views/admin/index.blade.php ENDPATH**/ ?>