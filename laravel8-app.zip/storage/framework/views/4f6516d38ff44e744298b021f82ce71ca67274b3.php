<?php $__env->startSection('section'); ?>
<div class="main-container">
		<div class="xs-pd-20-10 pd-ltr-20">
			<div class="page-header">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<div class="title">
							<h4>Dashboard</h4>
						</div>
						<nav aria-label="breadcrumb" role="navigation">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
							</ol>
						</nav>
					</div>
					<div class="col-md-6 col-sm-12 text-right">
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
							Tambah Buku
						</button>
					</div>
				</div>
			</div>
				<div class="row clearfix">
				<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-3 col-md-6 col-sm-12 mb-30 ">
						<div class="da-card">
							<div class="da-card-photo">
								<img src="<?php echo e(asset('admin/vendors/images/photo1.jpg')); ?>" alt="">
								<div class="da-overlay">
									<div class="da-social">
										<ul class="clearfix">
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-envelope-o"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="da-card-content">
								<h5 class="h5 mb-10"><?php echo e($b->judul); ?></h5>
							<table class="table">
									<tr>
										<th>ISBN</th>
										<th>Cover</th>
										<!-- <th>Idpengarang</th>
										<th>Idpenerbit</th>
										<th>Idkategori</th>
										<th>Idrak</th> -->
									</tr>
									<tr>
										<td><?php echo e($b->isbn); ?></td>
										<td><?php echo e($b->cover); ?></td>
										<!-- <td><?php echo e($b->idpengarang); ?></td>
										<td><?php echo e($b->idpenerbit); ?></td>
										<td><?php echo e($b->idkategori); ?></td>
										<td><?php echo e($b->idrak); ?></td> -->
									</tr>
							</table>
							<form action="<?php echo e(route('buku.destroy',$b->id)); ?>" method="POST">
							<a class="btn btn-primary" href="<?php echo e(route('buku.edit',$b->id)); ?>">Edit</a>
							</a>
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<button type="submit" class="btn btn-danger" onclick="return confirm('data yakin dihapus?')">Delete</i></button>
								
							</form>
							</div>
						</div>
					</div>
					
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

<br>
			
		

	<?php echo $__env->make('admin.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-TA\laravel8-app\resources\views/admin/index.blade.php ENDPATH**/ ?>