

<?php $__env->startSection('content'); ?>

<div class="login-wrap">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6">
					<div class="login-box bg-white box-shadow border-radius-10">
						<div class="login-title">
							<h2 class="text-center text-primary">Login to App</h2>
						</div>
						<form action="<?php echo e(url('login')); ?>" method="post">
				          <?php echo csrf_field(); ?>
				          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						      <div class="form-control-feedback has-danger"><?php echo e($message); ?></div>
				      		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				          <div class="input-group custom">
				            <input type="text" class="form-control form-control-lg" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
				            <div class="input-group-append custom">
				              <span class="input-group-text"><i class="icon-copy dw dw-user1"></i></span>
				            </div>
				          </div>

				          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						      <div class="form-control-feedback has-danger"><?php echo e($message); ?></div>
				      		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				          <div class="input-group custom">
				            <input type="password" class="form-control form-control-lg" placeholder="**********" name="password">
				            <div class="input-group-append custom">
				              <span class="input-group-text"><i class="dw dw-padlock1"></i></span>
				            </div>
				          </div>
				          <div class="row pb-30">
				            <div class="col-6">
				            </div>
				            <div class="col-6">
				              <div class="forgot-password"><a href="">Forgot Password</a></div>
				            </div>
				          </div>
				          <div class="row">
				            <div class="col-sm-12">
				              <div class="input-group mb-0">
				                <input class="btn btn-primary btn-lg btn-block" type="submit" value="Sign In">  
				              </div>
				            </div>
				          </div>
				        </form>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<?php $__env->stopSection(); ?>



<?php echo $__env->make('landingpage.buku.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\laravel8-app\resources\views/login/login.blade.php ENDPATH**/ ?>