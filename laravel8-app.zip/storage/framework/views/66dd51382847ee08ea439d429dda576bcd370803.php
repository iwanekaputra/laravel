<div class="left-side-bar">
		<div class="brand-logo">
			<a href="">
				<img src="<?php echo e(asset('admin/vendors/images/logo-icon.png')); ?>" alt="" class="light-logo">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu"><br/><br>
					<li>
						<a href="<?php echo e(url('/buku')); ?>" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-house-1"></span><span class="mtext">Dashboard</span>
						</a>
					</li>
					<li>
						<a href="" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-user1"></span><span class="mtext">Data Anggota</span>
						</a>
					</li>
						<a href="" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-notebook"></span><span class="mtext">Data Buku</span>
						</a>
					</li>
					<li>
						<a href="" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-house-1"></span><span class="mtext">Transaksi</span>
						</a>
					</li>
					<li>
						<a href="" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-notepad"></span><span class="mtext">Data Denda</span>
						</a>
					</li><i class="icon-copy "></i>
						<div class="dropdown-divider"></div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="mobile-menu-overlay"></div><?php /**PATH C:\xampp\htdocs\project-TA\laravel8-app\resources\views/admin/left_sidebar.blade.php ENDPATH**/ ?>